import sys
from pathlib import Path
import logging
from typing import Optional, List, Dict, Any

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from aiogram import Router, F, Bot  # type: ignore
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton  # type: ignore
from aiogram.filters import Command  # type: ignore

from config.settings import settings
from database.queries import (
    get_user_language,
    set_user_language,
    get_user_hot_deals_status,
    toggle_user_hot_deals,
    get_user_hot_deals_settings,
    update_user_hot_deals_settings,
    get_user_filters,
    get_filter_by_id,
    toggle_filter_status,
    delete_filter,
    get_database_stats
)
from bot.locales.texts import t, LANGUAGES
from bot.middlewares.i18n import set_cached_user_language

logger = logging.getLogger(__name__)

router = Router()


def get_language_keyboard() -> InlineKeyboardMarkup:
    """Build language selection inline buttons."""
    buttons = [
        [
            InlineKeyboardButton(text="🇬🇧 English", callback_data="set_lang_en"),
            InlineKeyboardButton(text="🇵🇱 Polski", callback_data="set_lang_pl"),
            InlineKeyboardButton(text="🇷🇺 Русский", callback_data="set_lang_ru")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def get_settings_keyboard(lang: str, hot_deals_enabled: bool = True) -> InlineKeyboardMarkup:
    """Build settings keyboard with language selection, Hot Deals toggle, detailed preferences, and main menu."""
    hd_btn_text = t("btn_hot_deals_on", lang) if hot_deals_enabled else t("btn_hot_deals_off", lang)
    buttons = [
        [
            InlineKeyboardButton(text="🇬🇧 English", callback_data="set_lang_en"),
            InlineKeyboardButton(text="🇵🇱 Polski", callback_data="set_lang_pl"),
            InlineKeyboardButton(text="🇷🇺 Русский", callback_data="set_lang_ru")
        ],
        [
            InlineKeyboardButton(text=hd_btn_text, callback_data="toggle_hot_deals")
        ],
        [
            InlineKeyboardButton(text=t("btn_hot_deals_settings", lang), callback_data="btn_hot_deals_menu")
        ],
        [
            InlineKeyboardButton(text=t("btn_main_menu", lang), callback_data="btn_main_menu")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def format_interval_label(interval_hours: int, lang: str) -> str:
    """Format interval hours to localized text."""
    if interval_hours == 0:
        return t("interval_realtime", lang)
    elif interval_hours == 1:
        return t("interval_1h", lang)
    elif interval_hours == 3:
        return t("interval_3h", lang)
    elif interval_hours == 6:
        return t("interval_6h", lang)
    elif interval_hours == 24:
        return t("interval_24h", lang)
    return f"{interval_hours}h"


def build_hot_deals_dashboard_text(hd: Dict[str, Any], lang: str) -> str:
    """Format Hot Deals preferences dashboard header."""
    status_label = t("status_active", lang) if hd["enabled"] else t("status_disabled", lang)
    min_profit_str = f"{int(hd['min_profit_eur']):,}".replace(",", " ")
    min_year_str = f"{hd['min_year']}+" if hd["min_year"] > 0 else t("any_year", lang)
    max_price_str = f"≤ {int(hd['max_price_eur']):,} €".replace(",", " ") if hd["max_price_eur"] > 0 else t("unlimited_price", lang)
    interval_str = format_interval_label(hd["interval_hours"], lang)

    return t(
        "hot_deals_dashboard_title",
        lang,
        status=status_label,
        min_profit=min_profit_str,
        min_year=min_year_str,
        max_price=max_price_str,
        interval=interval_str
    )


def build_hot_deals_dashboard_keyboard(hd: Dict[str, Any], lang: str) -> InlineKeyboardMarkup:
    """Build Hot Deals preferences dashboard buttons."""
    status_text = f"🔘 Status: {t('status_active', lang)}" if hd["enabled"] else f"🔘 Status: {t('status_disabled', lang)}"
    min_profit_str = f"≥ {int(hd['min_profit_eur'])} €"
    min_year_str = f"{hd['min_year']}+" if hd["min_year"] > 0 else t("any_year", lang)
    max_price_str = f"≤ {int(hd['max_price_eur'])} €" if hd["max_price_eur"] > 0 else t("unlimited_price", lang)
    interval_str = format_interval_label(hd["interval_hours"], lang)

    buttons = [
        [
            InlineKeyboardButton(text=status_text, callback_data="hd_toggle_status")
        ],
        [
            InlineKeyboardButton(text=f"💰 Profit: {min_profit_str}", callback_data="hd_param_profit"),
            InlineKeyboardButton(text=f"📅 Year: {min_year_str}", callback_data="hd_param_year")
        ],
        [
            InlineKeyboardButton(text=f"🏷️ Price: {max_price_str}", callback_data="hd_param_price"),
            InlineKeyboardButton(text=f"⏱️ Interval: {interval_str}", callback_data="hd_param_interval")
        ],
        [
            InlineKeyboardButton(text=t("btn_back_to_settings", lang), callback_data="btn_settings")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def get_main_menu_keyboard(lang: str) -> InlineKeyboardMarkup:
    """Build localized main menu buttons."""
    buttons = [
        [
            InlineKeyboardButton(text=t("btn_new_search", lang), callback_data="btn_new_search"),
            InlineKeyboardButton(text=t("btn_my_topics", lang), callback_data="btn_my_topics")
        ],
        [
            InlineKeyboardButton(text=t("btn_stats", lang), callback_data="btn_stats"),
            InlineKeyboardButton(text=t("btn_help", lang), callback_data="btn_help")
        ],
        [
            InlineKeyboardButton(text=t("btn_settings", lang), callback_data="btn_settings")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def format_topic_link(group_chat_id: Any, topic_id: int) -> str:
    """Generate Telegram URL to forum topic."""
    chat_str = str(group_chat_id).strip()
    if chat_str.startswith("@"):
        username = chat_str.lstrip("@")
        return f"https://t.me/{username}/{topic_id}"
    clean_id = chat_str
    if clean_id.startswith("-100"):
        clean_id = clean_id[4:]
    elif clean_id.startswith("-"):
        clean_id = clean_id[1:]
    return f"https://t.me/c/{clean_id}/{topic_id}"


# ==============================================================================
# /START & LANGUAGE SELECTION
# ==============================================================================

@router.message(Command("start"))
async def cmd_start(message: Message, lang: str = "en"):
    """Handle /start command with user language detection."""
    if not message.from_user:
        return
    user_id = message.from_user.id
    existing_lang = await get_user_language(user_id)

    if not existing_lang:
        # Prompt for language first
        await message.answer(
            t("select_language", "en"),
            reply_markup=get_language_keyboard(),
            parse_mode="HTML"
        )
    else:
        # User already registered, display main menu in their language
        await message.answer(
            t("welcome_message", existing_lang),
            reply_markup=get_main_menu_keyboard(existing_lang),
            parse_mode="HTML"
        )


@router.callback_query(F.data.startswith("set_lang_"))
async def callback_set_language(callback: CallbackQuery):
    """Set selected language, persist to DB and memory cache, and show main menu."""
    if not callback.data:
        await callback.answer()
        return

    target_lang = callback.data.replace("set_lang_", "").lower()
    if target_lang not in LANGUAGES:
        target_lang = "en"

    if not callback.from_user:
        await callback.answer()
        return

    user_id = callback.from_user.id
    await set_user_language(user_id, target_lang)
    set_cached_user_language(user_id, target_lang)

    success_text = (
        f"{t('language_saved', target_lang)}\n\n"
        f"{t('welcome_message', target_lang)}"
    )

    if isinstance(callback.message, Message):
        await callback.message.edit_text(
            success_text,
            reply_markup=get_main_menu_keyboard(target_lang),
            parse_mode="HTML"
        )
    await callback.answer()


# ==============================================================================
# /SETTINGS
# ==============================================================================

@router.message(Command("settings"))
@router.callback_query(F.data == "btn_settings")
async def cmd_settings(event: Message | CallbackQuery, lang: str = "en"):
    """Show settings and allow language change and Hot Deals toggle."""
    if not event.from_user:
        return
    user_id = event.from_user.id
    hot_deals_enabled = await get_user_hot_deals_status(user_id)
    current_lang_name = LANGUAGES.get(lang, "English")
    status_label = t("status_active", lang) if hot_deals_enabled else t("status_disabled", lang)
    text = t("settings_title", lang, current_lang=current_lang_name, hot_deals_status=status_label)
    kb = get_settings_keyboard(lang, hot_deals_enabled)

    if isinstance(event, CallbackQuery):
        if isinstance(event.message, Message):
            await event.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
        await event.answer()
    else:
        await event.answer(text, reply_markup=kb, parse_mode="HTML")


@router.callback_query(F.data == "toggle_hot_deals")
async def callback_toggle_hot_deals(callback: CallbackQuery, lang: str = "en"):
    """Toggle Hot Deals notifications on/off for user."""
    if not callback.from_user:
        await callback.answer()
        return
    user_id = callback.from_user.id
    new_status = await toggle_user_hot_deals(user_id)
    alert_msg = t("hot_deals_enabled_alert", lang) if new_status else t("hot_deals_disabled_alert", lang)

    current_lang_name = LANGUAGES.get(lang, "English")
    status_label = t("status_active", lang) if new_status else t("status_disabled", lang)
    text = t("settings_title", lang, current_lang=current_lang_name, hot_deals_status=status_label)
    kb = get_settings_keyboard(lang, new_status)

    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer(alert_msg, show_alert=True)


# ==============================================================================
# HOT DEALS DASHBOARD & PARAMETER HANDLERS
# ==============================================================================

@router.callback_query(F.data == "btn_hot_deals_menu")
async def callback_hot_deals_menu(callback: CallbackQuery, lang: str = "en"):
    """Show Hot Deals preferences dashboard."""
    if not callback.from_user:
        await callback.answer()
        return
    user_id = callback.from_user.id
    hd = await get_user_hot_deals_settings(user_id)
    text = build_hot_deals_dashboard_text(hd, lang)
    kb = build_hot_deals_dashboard_keyboard(hd, lang)
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "hd_toggle_status")
async def callback_hd_toggle_status(callback: CallbackQuery, lang: str = "en"):
    """Toggle hot deals status from dashboard."""
    if not callback.from_user:
        await callback.answer()
        return
    user_id = callback.from_user.id
    current = await get_user_hot_deals_settings(user_id)
    new_enabled = not current["enabled"]
    updated = await update_user_hot_deals_settings(user_id, enabled=new_enabled)
    text = build_hot_deals_dashboard_text(updated, lang)
    kb = build_hot_deals_dashboard_keyboard(updated, lang)
    alert = t("hot_deals_enabled_alert", lang) if new_enabled else t("hot_deals_disabled_alert", lang)
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer(alert, show_alert=True)


@router.callback_query(F.data == "hd_param_profit")
async def callback_hd_param_profit(callback: CallbackQuery, lang: str = "en"):
    """Select minimum net profit."""
    text = t("choose_min_profit", lang)
    buttons = [
        [
            InlineKeyboardButton(text="≥ 1 000 €", callback_data="hd_set_profit_1000"),
            InlineKeyboardButton(text="≥ 1 500 €", callback_data="hd_set_profit_1500")
        ],
        [
            InlineKeyboardButton(text="≥ 2 000 €", callback_data="hd_set_profit_2000"),
            InlineKeyboardButton(text="≥ 3 000 €", callback_data="hd_set_profit_3000")
        ],
        [
            InlineKeyboardButton(text="≥ 5 000 €", callback_data="hd_set_profit_5000")
        ],
        [
            InlineKeyboardButton(text=t("btn_back_to_hd", lang), callback_data="btn_hot_deals_menu")
        ]
    ]
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("hd_set_profit_"))
async def callback_hd_set_profit(callback: CallbackQuery, lang: str = "en"):
    """Save selected profit and return to dashboard."""
    if not callback.data or not callback.from_user:
        await callback.answer()
        return
    val = float(callback.data.replace("hd_set_profit_", ""))
    user_id = callback.from_user.id
    updated = await update_user_hot_deals_settings(user_id, min_profit_eur=val)
    text = build_hot_deals_dashboard_text(updated, lang)
    kb = build_hot_deals_dashboard_keyboard(updated, lang)
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer(t("hd_param_updated", lang))


@router.callback_query(F.data == "hd_param_year")
async def callback_hd_param_year(callback: CallbackQuery, lang: str = "en"):
    """Select minimum car year."""
    text = t("choose_min_year", lang)
    buttons = [
        [
            InlineKeyboardButton(text=t("any_year", lang), callback_data="hd_set_year_0"),
            InlineKeyboardButton(text="2010+", callback_data="hd_set_year_2010")
        ],
        [
            InlineKeyboardButton(text="2012+", callback_data="hd_set_year_2012"),
            InlineKeyboardButton(text="2015+", callback_data="hd_set_year_2015")
        ],
        [
            InlineKeyboardButton(text="2018+", callback_data="hd_set_year_2018"),
            InlineKeyboardButton(text="2020+", callback_data="hd_set_year_2020")
        ],
        [
            InlineKeyboardButton(text="2022+", callback_data="hd_set_year_2022")
        ],
        [
            InlineKeyboardButton(text=t("btn_back_to_hd", lang), callback_data="btn_hot_deals_menu")
        ]
    ]
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("hd_set_year_"))
async def callback_hd_set_year(callback: CallbackQuery, lang: str = "en"):
    """Save selected year and return to dashboard."""
    if not callback.data or not callback.from_user:
        await callback.answer()
        return
    val = int(callback.data.replace("hd_set_year_", ""))
    user_id = callback.from_user.id
    updated = await update_user_hot_deals_settings(user_id, min_year=val)
    text = build_hot_deals_dashboard_text(updated, lang)
    kb = build_hot_deals_dashboard_keyboard(updated, lang)
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer(t("hd_param_updated", lang))


@router.callback_query(F.data == "hd_param_price")
async def callback_hd_param_price(callback: CallbackQuery, lang: str = "en"):
    """Select maximum car purchase price."""
    text = t("choose_max_price", lang)
    buttons = [
        [
            InlineKeyboardButton(text=t("unlimited_price", lang), callback_data="hd_set_price_0"),
            InlineKeyboardButton(text="≤ 10 000 €", callback_data="hd_set_price_10000")
        ],
        [
            InlineKeyboardButton(text="≤ 15 000 €", callback_data="hd_set_price_15000"),
            InlineKeyboardButton(text="≤ 20 000 €", callback_data="hd_set_price_20000")
        ],
        [
            InlineKeyboardButton(text="≤ 30 000 €", callback_data="hd_set_price_30000"),
            InlineKeyboardButton(text="≤ 50 000 €", callback_data="hd_set_price_50000")
        ],
        [
            InlineKeyboardButton(text=t("btn_back_to_hd", lang), callback_data="btn_hot_deals_menu")
        ]
    ]
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("hd_set_price_"))
async def callback_hd_set_price(callback: CallbackQuery, lang: str = "en"):
    """Save selected price and return to dashboard."""
    if not callback.data or not callback.from_user:
        await callback.answer()
        return
    val = float(callback.data.replace("hd_set_price_", ""))
    user_id = callback.from_user.id
    updated = await update_user_hot_deals_settings(user_id, max_price_eur=val)
    text = build_hot_deals_dashboard_text(updated, lang)
    kb = build_hot_deals_dashboard_keyboard(updated, lang)
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer(t("hd_param_updated", lang))


@router.callback_query(F.data == "hd_param_interval")
async def callback_hd_param_interval(callback: CallbackQuery, lang: str = "en"):
    """Select alert frequency interval."""
    text = t("choose_interval", lang)
    buttons = [
        [
            InlineKeyboardButton(text=t("interval_realtime", lang), callback_data="hd_set_interval_0"),
            InlineKeyboardButton(text=t("interval_1h", lang), callback_data="hd_set_interval_1")
        ],
        [
            InlineKeyboardButton(text=t("interval_3h", lang), callback_data="hd_set_interval_3"),
            InlineKeyboardButton(text=t("interval_6h", lang), callback_data="hd_set_interval_6")
        ],
        [
            InlineKeyboardButton(text=t("interval_24h", lang), callback_data="hd_set_interval_24")
        ],
        [
            InlineKeyboardButton(text=t("btn_back_to_hd", lang), callback_data="btn_hot_deals_menu")
        ]
    ]
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("hd_set_interval_"))
async def callback_hd_set_interval(callback: CallbackQuery, lang: str = "en"):
    """Save selected interval and return to dashboard."""
    if not callback.data or not callback.from_user:
        await callback.answer()
        return
    val = int(callback.data.replace("hd_set_interval_", ""))
    user_id = callback.from_user.id
    updated = await update_user_hot_deals_settings(user_id, interval_hours=val)
    text = build_hot_deals_dashboard_text(updated, lang)
    kb = build_hot_deals_dashboard_keyboard(updated, lang)
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer(t("hd_param_updated", lang))


@router.callback_query(F.data == "btn_main_menu")
async def callback_main_menu(callback: CallbackQuery, lang: str = "en"):
    """Return to main menu."""
    text = t("welcome_message", lang)
    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=get_main_menu_keyboard(lang), parse_mode="HTML")
    await callback.answer()


# ==============================================================================
# /MY_TOPICS & TOPIC MANAGEMENT
# ==============================================================================

@router.message(Command("my_topics"))
@router.message(Command("filters"))
@router.callback_query(F.data.in_(["btn_my_topics", "btn_my_filters"]))
async def cmd_my_topics(event: Message | CallbackQuery, lang: str = "en"):
    """List and manage user's forum topics."""
    if not event.from_user:
        return
    user_id = event.from_user.id
    filters = await get_user_filters(user_id)

    if not filters:
        no_topics_text = t("no_topics_found", lang)
        if isinstance(event, CallbackQuery):
            if isinstance(event.message, Message):
                await event.message.edit_text(no_topics_text, reply_markup=get_main_menu_keyboard(lang), parse_mode="HTML")
            await event.answer()
        else:
            await event.answer(no_topics_text, reply_markup=get_main_menu_keyboard(lang), parse_mode="HTML")
        return

    # Build topic list message
    lines = [f"{t('my_topics_title', lang)}\n"]
    for idx, f in enumerate(filters, start=1):
        status_str = t("status_active", lang) if f["is_active"] == 1 else t("status_paused", lang)
        
        # Build short name
        make = f["make"]
        model = f["model"] or ""
        y_min, y_max = f.get("year_min"), f.get("year_max")
        price_max = f.get("price_max_eur")

        details = []
        if y_min and y_max:
            details.append(f"{y_min}-{y_max}")
        elif y_min:
            details.append(f">{y_min}")
        if price_max:
            details.append(f"<{price_max:,.0f}€".replace(",", ""))

        details_str = f" ({', '.join(details)})" if details else ""
        lines.append(f"<b>{idx}.</b> 🚙 {make} {model}{details_str} — [{status_str}]")

    header_text = "\n".join(lines)
    
    # We display control keyboards for each topic
    buttons = []
    for f in filters[:8]:  # show up to 8 topics with quick control buttons
        fid = f["id"]
        tid = f["topic_id"]
        status_action = t("btn_pause", lang) if f["is_active"] == 1 else t("btn_resume", lang)
        
        row = []
        if tid and tid > 0:
            topic_url = format_topic_link(settings.GROUP_CHAT_ID, tid)
            row.append(InlineKeyboardButton(text=f"🔗 #{fid}", url=topic_url))
        
        row.append(InlineKeyboardButton(text=f"{status_action}", callback_data=f"topic_toggle_{fid}"))
        row.append(InlineKeyboardButton(text=t("btn_delete_topic", lang), callback_data=f"topic_del_prompt_{fid}"))
        buttons.append(row)

    buttons.append([InlineKeyboardButton(text=t("btn_new_search", lang), callback_data="btn_new_search")])
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)

    if isinstance(event, CallbackQuery):
        if isinstance(event.message, Message):
            await event.message.edit_text(header_text, reply_markup=kb, parse_mode="HTML")
        await event.answer()
    else:
        await event.answer(header_text, reply_markup=kb, parse_mode="HTML")


@router.callback_query(F.data.startswith("topic_toggle_"))
async def callback_topic_toggle(callback: CallbackQuery, lang: str = "en"):
    """Toggle a topic between active and paused."""
    if not callback.data or not callback.from_user:
        await callback.answer()
        return
    fid = int(callback.data.replace("topic_toggle_", ""))
    flt = await get_filter_by_id(fid)
    if not flt or flt["user_id"] != callback.from_user.id:
        await callback.answer("Topic not found", show_alert=True)
        return

    await toggle_filter_status(fid)
    await cmd_my_topics(callback, lang=lang)


@router.callback_query(F.data.startswith("topic_del_prompt_"))
async def callback_topic_delete_prompt(callback: CallbackQuery, lang: str = "en"):
    """Confirm topic deletion."""
    if not callback.data or not callback.from_user:
        await callback.answer()
        return
    fid = int(callback.data.replace("topic_del_prompt_", ""))
    flt = await get_filter_by_id(fid)
    if not flt or flt["user_id"] != callback.from_user.id:
        await callback.answer("Topic not found", show_alert=True)
        return

    text = f"{t('confirm_delete_prompt', lang)}\n\n🚙 <b>{flt['make']} {flt.get('model') or ''}</b>"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=t("btn_confirm_yes", lang), callback_data=f"topic_del_confirm_{fid}"),
            InlineKeyboardButton(text=t("btn_confirm_no", lang), callback_data="btn_my_topics")
        ]
    ])

    if isinstance(callback.message, Message):
        await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("topic_del_confirm_"))
async def callback_topic_delete_confirm(callback: CallbackQuery, bot: Bot, lang: str = "en"):
    """Execute topic deletion, close forum topic in Telegram and delete from DB."""
    if not callback.data or not callback.from_user:
        await callback.answer()
        return
    fid = int(callback.data.replace("topic_del_confirm_", ""))
    flt = await get_filter_by_id(fid)
    if not flt or flt["user_id"] != callback.from_user.id:
        await callback.answer("Topic not found", show_alert=True)
        return

    topic_id = flt.get("topic_id")
    if topic_id and topic_id > 0:
        try:
            await bot.close_forum_topic(chat_id=settings.GROUP_CHAT_ID, message_thread_id=topic_id)
        except Exception as e:
            logger.debug(f"Could not close forum topic {topic_id}: {e}")

    await delete_filter(fid)
    
    if isinstance(callback.message, Message):
        await callback.message.edit_text(t("topic_deleted_success", lang), reply_markup=get_main_menu_keyboard(lang), parse_mode="HTML")
    await callback.answer()


# ==============================================================================
# /STATS & /HELP
# ==============================================================================

@router.message(Command("stats"))
@router.callback_query(F.data == "btn_stats")
async def cmd_stats(event: Message | CallbackQuery, lang: str = "en"):
    """Display real-time statistics."""
    stats = await get_database_stats()
    text = t(
        "stats_template",
        lang,
        total_users=stats.get("total_users", 0),
        active_filters=stats.get("active_filters", 0),
        total_topics=stats.get("total_topics", 0),
        seen_listings=f"{stats.get('seen_listings', 0):,}".replace(",", " "),
        cached_benchmarks=f"{stats.get('cached_benchmarks', 0):,}".replace(",", " ")
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t("btn_main_menu", lang), callback_data="btn_main_menu")]
    ])

    if isinstance(event, CallbackQuery):
        if isinstance(event.message, Message):
            await event.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
        await event.answer()
    else:
        await event.answer(text, reply_markup=kb, parse_mode="HTML")


@router.message(Command("help"))
@router.callback_query(F.data == "btn_help")
async def cmd_help(event: Message | CallbackQuery, lang: str = "en"):
    """Display detailed help guide."""
    help_text = (
        "📖 <b>Pan-European Arbitrage System & Rules</b>\n\n"
        "1️⃣ <b>Filter Setup & Dynamic Topic:</b>\n"
        "Use <code>/newfilter</code> to choose country, make, model, year range, budget, mileage, and fuel type. "
        "The bot will automatically create a dedicated topic in the group and pin filter parameters as the first message.\n\n"
        "2️⃣ <b>Multi-Tier Live Scanner:</b>\n"
        "• Tier 1 (Simple HTML): SS.com (LV), Bazos.sk (SK), Bazos.cz (CZ)\n"
        "• Tier 2 (Moderate Protection): Autoplius.lt (LT), Sauto.cz (CZ)\n"
        "• Tier 3 (Major Western Markets): Mobile.de (DE), Kleinanzeigen.de (DE), Leboncoin.fr (FR), Subito.it (IT)\n\n"
        "3️⃣ <b>Net Arbitrage Calculation:</b>\n"
        "<code>Net Profit = Otomoto Price - (Purchase + Logistics + Excise + Registration)</code>\n"
        "• Logistics: Baltics ~400€, Czech/Slovakia ~300€, Germany ~500€, Western Europe ~850€\n"
        "• Akcyza (Excise): Engine ≤2.0L 3.1%, >2.0L 18.6%, Hybrid 1.55%, EV 0%\n"
        "• Registration/Inspection: 300 PLN (~70€)\n\n"
        "4️⃣ <b>🔥 Hot Deals:</b>\n"
        "If net profit is <b>≥1 500 €</b> or <b>≥15% below market price</b>, the listing is instantly forwarded to <code>#HotDeals</code>!"
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t("btn_main_menu", lang), callback_data="btn_main_menu")]
    ])

    if isinstance(event, CallbackQuery):
        if isinstance(event.message, Message):
            await event.message.edit_text(help_text, reply_markup=kb, parse_mode="HTML")
        await event.answer()
    else:
        await event.answer(help_text, reply_markup=kb, parse_mode="HTML")

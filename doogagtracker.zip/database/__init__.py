from database.db import get_db, init_db
from database.queries import (
    create_user_filter,
    get_active_filters,
    get_user_filters,
    get_filter_by_id,
    update_filter_topic,
    toggle_filter_status,
    delete_filter,
    is_listing_seen,
    save_seen_listing,
    get_market_benchmark,
    save_market_benchmark,
    get_poland_benchmark,
    save_poland_benchmark,
    get_database_stats
)

__all__ = [
    "get_db",
    "init_db",
    "create_user_filter",
    "get_active_filters",
    "get_user_filters",
    "get_filter_by_id",
    "update_filter_topic",
    "toggle_filter_status",
    "delete_filter",
    "is_listing_seen",
    "save_seen_listing",
    "get_market_benchmark",
    "save_market_benchmark",
    "get_poland_benchmark",
    "save_poland_benchmark",
    "get_database_stats"
]

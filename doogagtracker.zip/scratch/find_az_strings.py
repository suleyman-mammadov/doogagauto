import os
import re

AZ_LETTERS = set("əğıöüçşƏĞIÖÜÇŞ")
AZ_WORDS = ["axtarış", "filtrlərim", "qrup", "şəxsi", "elan", "keçir", "yürüş", "yanacaq", "qutusu", "qiymət"]

for root, dirs, files in os.walk("."):
    if ".git" in root or ".venv" in root or "__pycache__" in root or "scratch" in root:
        continue
    for file in files:
        if file.endswith(".py"):
            path = os.path.join(root, file)
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for line_no, line in enumerate(f, 1):
                    # check for az characters or specific words
                    if any(c in AZ_LETTERS for c in line) or any(w in line.lower() for w in AZ_WORDS):
                        # Filter out comments if possible or show
                        s = line.strip()
                        if s.startswith("#") and "texts.py" not in path:
                            continue
                        print(f"{path}:{line_no}: {s[:120]}")
